package Rcur;

import java.util.Scanner;

public class Recursividad {

	  // M�todo para calcular la potencia usando recursividad
    static double power(float num, int exp) {
      if (exp==0) 
         return 1;
      else
         return num*power(num, exp-1);
    }
  
    public static void main(String[] args) {
    	try {
    		} catch (Exception e) {
    		  System.out.println("Algo sali� mal.");
    		}
        Scanner sc = new Scanner(System.in);

        // Pedir al usuario que ingrese los n�meros
        System.out.print("Ingresa el n�mero A: ");
        float num = sc.nextFloat();
        System.out.print("Ingresa el n�mero B: ");
        int exp = 0;
        try {
        	exp = sc.nextInt();
		} catch (Exception e) {
			  System.out.println("Algo sali� mal.");
			  exp = 0;
		}
        

        // Calcular la potencia de A elevado a B
        double resultado = power(num, exp);
        System.out.println("El resultado es: " + resultado);
    }
}